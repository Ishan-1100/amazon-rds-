import * as cdk from 'aws-cdk-lib';
import { Construct } from '@aws-cdk/core';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { CfnParameter } from 'aws-cdk-lib';
import { SecurityGroup, Peer, Port } from 'aws-cdk-lib/aws-ec2';

/*
import * as IpAddress from 'ip-address';
export var ipv4 = IpAddress.Address4;
export var ipv6 = IpAddress.Address6;
*/


export class SG extends cdk.Stack{

    constructor(scope: cdk.App, id: string, props?: cdk.StackProps) {
        super(scope, id, props);


        //vpc
        const vpc = new ec2.Vpc(this, 'my-cdk-vpc', {
            cidr: '10.0.0.0/16',
            natGateways: 0,
            maxAzs: 3,
            subnetConfiguration: [
              {
                name: 'public-subnet-1',
                subnetType: ec2.SubnetType.PUBLIC,
                cidrMask: 24,
              },
            ],
          });


          const ipAddressParam = new CfnParameter(this, 'IpAddress', {
            type: 'String',
            description: 'Enter the IP address',
            default: '127.0.0.1', // Default IP address
          });
          
          const portParam = new CfnParameter(this, 'Port', {
            type: 'Number',
            description: 'Enter the port number',
            default: 80, // Default port number
          });


          // Create the security group
            const securityGroup = new SecurityGroup(this, 'MySecurityGroup', {
                vpc: vpc, // Replace with your VPC reference
                allowAllOutbound: true,
                    });

          securityGroup.addIngressRule(Peer.ipv4(ipAddressParam.valueAsString), Port.tcp(portParam.valueAsNumber), 'Allow inbound traffic');
        
        /*
          // 👇 Create a SG for a web server
    const webserverSG = new ec2.SecurityGroup(this, 'web-server-sg', {
        vpc,
        allowAllOutbound: true,
        description: 'security group for a web server',
      });

      webserverSG.addIngressRule(
        ec2.Peer.anyIpv4(),
        ec2.Port.tcp(22),
        'allow SSH access from anywhere',
      );
  
      webserverSG.addIngressRule(
        ec2.Peer.anyIpv4(),
        ec2.Port.tcp(80),
        'allow HTTP traffic from anywhere',
      );
  
      webserverSG.addIngressRule(
        ec2.Peer.anyIpv4(),
        ec2.Port.tcp(443),
        'allow HTTPS traffic from anywhere',
      );
  
      webserverSG.addIngressRule(
        ec2.Peer.ipv4('123.123.123.123/16'),
        ec2.Port.allIcmp(),
        'allow ICMP traffic from a specific IP range',
      );
    }
    */

 }

}